# Change Log

## v0.1.0

- make Python 3 compatible
- use json instead of pickle (pickle causes problems under Python 3)
- prepare upload of distribution package to PyPI
